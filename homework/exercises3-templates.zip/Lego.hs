module Lego where

import Data.List
import Data.Tuple

--removeAt :: Int -> [a] -> [a]

--sortWithPos :: (Ord a) => [a] -> [(a,Int)]

--sortedPos :: (Ord a) => [a] -> [(a,Int)]
