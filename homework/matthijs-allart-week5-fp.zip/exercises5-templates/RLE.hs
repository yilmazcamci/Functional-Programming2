module RLE where

import Data.List

-- encodeRLE :: (Eq a) => [a] -> [(a,Int)]
-- decodeRLE :: (Eq a) => [(a,Int)] -> [a]
