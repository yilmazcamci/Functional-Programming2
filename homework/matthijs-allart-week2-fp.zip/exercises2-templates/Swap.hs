module Swap where

swap (x,y) = (y,x)

