module Char where

import Data.Char

--(~~) :: String -> String -> Bool

--reverseCase :: String -> String

--shift :: Int -> Char -> Char

--caesar :: Int -> String -> String

msg :: String
msg = "ADMNO D HPNO NKMDIFGZ TJP RDOC AVDMT YPNO"
